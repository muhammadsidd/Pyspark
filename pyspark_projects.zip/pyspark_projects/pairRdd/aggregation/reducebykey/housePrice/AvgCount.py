class AvgCount():

    def __init__(self, count: int, total: float):
        self.count = count
        self.total = total


