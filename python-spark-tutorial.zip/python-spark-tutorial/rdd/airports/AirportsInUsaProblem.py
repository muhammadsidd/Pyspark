from pyspark import SparkConf, SparkContext
import re

def commasplit (line:str):
    split = re.compile(''',(?=(?:[^"]*"[^"]*")*[^"]*$)''').split(line)
    return "{},{}".format(split[1],split[2])

if __name__ == "__main__":

    conf = SparkConf().setAppName("Airports").setMaster("local[2]")
    sc = SparkContext(conf = conf)

    airport = sc.textFile("in/airports.text")
    usaairports = airport.filter(lambda line: re.compile(''',(?=(?:[^"]*"[^"]*")*[^"]*$)''').split(line)[3] == "\"United States\"")
    cityandport = usaairports.map(commasplit)
    cityandport.saveAsTextFile("out/airport_city.text")

    
